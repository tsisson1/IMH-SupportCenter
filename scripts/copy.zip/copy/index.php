<?

// http://stackoverflow.com/questions/49547/making-sure-a-web-page-is-not-cached-across-all-browsers
header('Cache-Control: no-cache, no-store, must-revalidate'); // HTTP 1.1.
header('Pragma: no-cache'); // HTTP 1.0.
header('Expires: 0'); // Proxies.

/**
 * Setup date and time settings. This is initially being setup to determine the time so we can
 * disable certain departments throuhout the week.
 */
date_default_timezone_set('America/New_York');
$date = new DateTime();
$hour = date("G",$date->getTimestamp());
$day = date("N",$date->getTimestamp()); /* 1 (for Monday) through 7 (for Sunday) */






// ----------------------------------------------------------------------------
// grab message from the database
// ----------------------------------------------------------------------------
include_once("../configuration.php");
$cg = new JConfig;
$con = mysqli_connect("localhost",$cg->user,$cg->password,$cg->db);

// if we cannot connect to the database
// ------------------------------------------------------------------------------------------------------------------
if (mysqli_connect_errno())
{
	$welcome_message = "<p>Welcome to chat!</p>";
}
// if we CAN connect to the database
// ------------------------------------------------------------------------------------------------------------------
else
{
	// ----------------------------------------------------------------
	// grab the current (id=1) and default message (id=2)
	// ----------------------------------------------------------------
	$query = "SELECT * FROM `" . $cg->dbprefix . "prechat_message`;";
	$result = mysqli_query($con,$query);
	while($row = mysqli_fetch_array($result))
	{
		switch($row['id'])
		{
			// case 1: current message
			case "1":
				$message_last_update = $row['last_update'];
			        $message_expiration = $row['expiration'];
			        $welcome_message = $row['message'];
				break;
			case "2":
				$default_message = $row['message'];
				break;
		}
	}
	// ----------------------------------------------------------------
	// has the message expired?
	// ----------------------------------------------------------------
	if( $message_expiration != "0" )
	{
        	$current_time = date("Y-m-d H:i:s");
	        $message_last_updated_seconds_ago = strtotime($current_time) - strtotime($message_last_update);

		// if updated 1 hour 1 second ago is greate than 1 hour expiration
		// if 3601 seconds is greater than 3600
		if( $message_last_updated_seconds_ago > ($message_expiration * 60 * 60) )
		{
			$query = "UPDATE `" . $cg->dbprefix . "prechat_message` SET `message` = '" . addslashes($default_message) . "', `last_update` = CURRENT_TIMESTAMP, `expiration` = 0 WHERE `id` = 1;";
			$result = mysqli_query($con,$query);
			$welcome_message = $default_message;
		}
	}
	else
		$welcome_message = $default_message;
	mysqli_close($con);
}






/**
 * setup chat departments
 */

// if we need to get the training departments
if( $_GET['rdid'] == "708918024841625095" OR $_GET['rdid'] == "794814027115867494" )
{
	/**
	 * These hard coded departments will be used as a fallback just in case the query below fails
	 * to get the departmetns
	 */
	$departments["708918024841625095"] = "Training - Support";
	$departments["794814027115867494"] = "Training - Sales";

	// grab the departments from the database
        $departments_from_db = pass_query_return_departments("  SELECT  `dep_id`,`dep_title`
                                                FROM    `" . $cg->dbprefix . "prechat_departments`
                                                WHERE   `group` = 'training' AND
                                                        `enabled` = 1
                                                ORDER BY `order` ASC;
                                                ");
        if($departments_from_db)
        {
                unset($departments);
                $departments = $departments_from_db;
        }
}
// else get the "production" departments (non training departments)
else
{
	/**
         * These hard coded departments will be used as a fallback just in case the query below fails
         * to get the departmetns
         */
	$departments["1621843185299383618"] = "Billing";
	$departments["4574741892902413188"] = "Sales - Business Class hosting";
	$departments["161470813524485003"] = "Sales - Custom Web Design";
	$departments["1943748019446294429"] = "Sales - Dedicated servers";
	$departments["3027061675179994483"] = "Sales - Reseller Hosting";
	$departments["1382987596054887839"] = "Sales - Virtual Private Servers (VPS)";
	$departments["2324923566971164486"] = "Technical Support 24/7";

	// grab the departments from the database
	$departments_from_db = pass_query_return_departments("	SELECT	`dep_id`,`dep_title`
						FROM	`" . $cg->dbprefix . "prechat_departments`
						WHERE	`group` = 'standard' AND
							`enabled` = 1
						ORDER BY `order` ASC;
						");
	if($departments_from_db)
	{
		unset($departments);
		$departments = $departments_from_db;
	}
}

/**
 * Setup disabled departments. For example, during overnight hours, sales team is not available
 */
// Web design sales - open Mon-Fri 9-6
if( ! ( $day <= 5 AND ( $hour >= 9 AND $hour < 18 ) ) ) {
	$disabled_department['161470813524485003'] = "disabled";
}

/**
 * Create the department <options> for the select tag
 */
foreach($departments as $dep_k => $dep_v) {
	// if the department is closed
	if( isset($disabled_department[$dep_k]) ) {
		$department_options .= "\n<option value='$dep_k' " . $disabled_department[$dep_k] . ">$dep_v (Closed)</option>";
	}
	// else, the department is open
	else {
		$department_options .= "\n<option value='$dep_k'>$dep_v</option>";
	}
}






?><html>

<head>

	<link rel="stylesheet" href="main.css?v=<? echo time(); ?>" type="text/css" />
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="main.js?v=<? echo time(); ?>" type="text/javascript"></script>

	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">

</head>

<body>

	<div class='logo'></div>

	<div class='main_container' name='main_container' id='main_container'>

		<? echo $welcome_message; ?>

		<form name='myform' id='prechatform' method='get' action='https://livechat.boldchat.com/aid/370246676985295205/bc.chat'>

			<input type="hidden" name="resize" value="true" />
			<input type="hidden" name="cwdid" value="4729630034290649077">
			<input type="hidden" name="cbdid" value="2766161325990137219" />
			<input type="hidden" name="wdid" value="2034694302371522916" />
			<input type="hidden" name="url" value="<? echo htmlentities($_GET['url'],ENT_QUOTES); ?>" />
			<input type="hidden" name="brand" id="brand" value="IMH" />
			<input type="hidden" name="vr" id="vr" value="IMH" />
			<input type="hidden" name="timestamp_n_id" id="timestamp_n_id" value="<? echo gmmktime() . rand(1000,1999); ?>" />
			<input type="hidden" name="ip" id="ip" value="<? echo $_SERVER['HTTP_X_FORWARDED_FOR']; ?>" />

			<p>
				<div class='field_title'>Your name: <span class='ras'>*</span></div>
				<input type='text' name='vn' id='vn' />
			</p>

			<p>
				<div class='field_title'>Your e-mail: <span class='ras'>*</span></div>
				<input type='text' name='ve' id='ve' />
			</p>

			<p>
				<div class='field_title'>What is your domain name?</div>
				<input type='text' name='vdn' id='vdn' />
			</p>

			<p>
				<div class='field_title'>Please select the most appropriate department <span class='ras'>*</span></div>
				<select id="rdid" name="rdid" class="radio_button" onChange="showNextButton();">
					<option value="" selected>
					<? echo $department_options; ?>
				</select>
			</p>

			<div>
				<div class='field_title'>What question may we help you with? <span class='ras'>*</span></div>
				<textarea name='iq' id='iq' onFocus="showNextButton();" ></textarea>
			</div>

			<p name='find_fast_support' id='find_fast_support'>You may find your answer faster within our Support Center:</p>

			<div name='loading_asr' id='loading_asr'>
				<input type='button' value='Next step' onClick='fetch_ajax_search_results();' class='blue_button' />
			</div>

			<div name='asr' id='asr'></div>

			<div name='asr_help' id='asr_help'>
				<input type='button' value='Search Again' onClick="searchAgain();" class='blue_button' />
				<input type='button' value='Launch Chat' onClick="launchChat();" class='blue_button' />
			</div>

			<a name='after_asr' id='after_asr'></a>

		</form>

	</div>

	<img src='loading.gif' style='display:none;' />

	<input type='hidden' name='research_count' id='research_count' value='0' />

</body>

</html>






<?

/**
 * pass a query and return all of the departments
 */
function pass_query_return_departments($query)
{
	include_once("../configuration.php");
	$cg = new JConfig;
	$con = mysqli_connect("localhost",$cg->user,$cg->password,$cg->db);

	if (mysqli_connect_errno())
	{
		return false;
	}
	else
	{
	        $result = mysqli_query($con,$query);
        	while($row = mysqli_fetch_array($result))
		{
			$departments[$row['dep_id']] = $row['dep_title'];
		}
		mysqli_close($con);

		return $departments;
	}
}

?>
