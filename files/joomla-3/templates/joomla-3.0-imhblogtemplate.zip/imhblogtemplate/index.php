<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  Templates.protostar
 *
 * @copyright   Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

$app = JFactory::getApplication();
$doc = JFactory::getDocument();

// Detecting Active Variables
$option   = $app->input->getCmd('option', '');
$view     = $app->input->getCmd('view', '');
$layout   = $app->input->getCmd('layout', '');
$task     = $app->input->getCmd('task', '');
$itemid   = $app->input->getCmd('Itemid', '');
$sitename = $app->getCfg('sitename');

$templateparams = $app->getTemplate(true)->params;
$config = JFactory::getConfig();

if($task == "edit" || $layout == "form" )
{
        $fullWidth = 1;
}
else
{
        $fullWidth = 0;
}

$f1c = $this->countModules('footer-1');
$f2c = $this->countModules('footer-2');
$f3c = $this->countModules('footer-3');
$f4c = $this->countModules('footer-4');
// Setup the top menu
$top_menu_count = $this->countModules('top-menu');
if($top_menu_count == 0 AND $templateparams->get('showTopMenuMessage'))
	$no_menu = "	<div style='float:left; padding:1px 4px 1px 5px; color:#fff; font-size:12px; line-height:13px; overflow:auto; max-height:37px;'>
				This is module position 'top-menu'. To place one of your menus here, update the module's postion so that it is <em>top-menu</em>. If you do not want to place a module here and you want to hide this message, access this template's settings within your Joomla! administrative dashboard and set the 'Show Top Menu Message' setting to 'No'.
			</div>
	";


// Add Stylesheets
$doc->addStyleSheet('templates/' . $this->template . '/css/style.css');
$doc->addStyleSheet('templates/' . $this->template . '/css/css.css');
$doc->addStyleSheet($this->baseurl . '/media/jui/css/bootstrap.css');
$doc->addStyleSheet('templates/' . $this->template . '/css/bootstrap-responsive.css');
// If Right-to-Left
if ($this->direction == 'rtl')
{
        $doc->addStyleSheet('media/jui/css/bootstrap-rtl.css');
}


JHtml::_('bootstrap.framework');
?>
<!DOCTYPE html>
<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">

	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<jdoc:include type="head" />

	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>

<body>

	<div class="container">

		<div class="row">

	        	<header class="span12">
        			<div class="span12">
					<h1 class="title">
						<?php if ($templateparams->get('sitetitle')): ?>
							<?php echo htmlspecialchars($templateparams->get('sitetitle'));?>
						<?php elseif ($config->get('sitename')): ?>
							<?php echo htmlspecialchars($config->get('sitename'));?>
						<?php endif; ?>
					</h1>
					<?php	if($templateparams->get('templateSubTitle') AND $templateparams->get('showTemplateSubTitle'))
							echo "<h2 class='subtitle'>  |  " . htmlspecialchars($templateparams->get('templateSubTitle')) . "</h2>";
					?>
                               <form class="form-search alignright" action='<?php echo $this->baseurl; ?>/index.php' method='post' class='form-inline'>
                                        <input class="input-medium search-query" type="text" name='searchword' id='mod-search-searchword' max-length='20' />
                                        <input type='hidden' name='task' value='search' />
                                        <input type='hidden' name='option' value='com_search' />
                                        <input type='hidden' name='Itemid' value='101' />
                                        <button type="submit" class="btn">Search</button>
                                </form>
				</div>
			</header>
			<div style='clear:both;'></div>

		        <nav class="span12">
				<?
					// show a message if the user had not yet put a menu in the top-menu module position
					 echo $no_menu;
				?>
				<jdoc:include type="modules" name="top-menu" />    
		        </nav>
			<div style='clear:both;'></div>
      

			<div id="main" class="span9">
				<article>
	                                <jdoc:include type="modules" name="position-3" style="xhtml" />
                                        <jdoc:include type="message" />
                                        <jdoc:include type="component" />
                                        <jdoc:include type="modules" name="position-2" style="none" />

    				</article>
			</div>
        
		    	<div class="span3">

				<?php if ($this->countModules('position-7')) : ?>
					<div id="aside" class="span3">
        				        <jdoc:include type="modules" name="position-7" style="xhtml" headerLevel="3" />
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>

        <div id="footerwrap">
		<div class="container">
        		 <div class="row">
				<?
					if( ($f1c == 0 AND $f2c == 0 AND $f3c == 0 AND $f4c == 0) AND $templateparams->get('showFooterMessage') == 1 )
					{
				?>
				<footer class="span12">
					<p>
						This is the footer of your template. It is divided into the following 4 columns (module positions):
					</p>
					<ul>
						<li>footer-1</li>
						<li>footer-2</li>
						<li>footer-3</li>
						<li>footer-4</li>
					</ul>
					<p>
						If you want to place content in your footer, update the module(s) of your choice to display in one of the module positions listed above. If you do not want to place any modules in your footer at this time, go to the settings for this template in your Joomla! administrative dashboard and update the setting to hide this footer message.
					</p>
				</footer>

				<?
					}
					else
					{
				?>
			         <footer class="span12">
				         <div class="footer-widget span3">
						<jdoc:include type="modules" name="footer-1" style="xhtml" headerLevel="3" />
				         </div>
				         <div class="footer-widget span3">
						<jdoc:include type="modules" name="footer-2" style="xhtml" headerLevel="3" />
				         </div>
				        <div class="footer-widget span3">
						<jdoc:include type="modules" name="footer-3" style="xhtml" headerLevel="3" />
				         </div>
				         <div class="footer-widget span2">
						<jdoc:include type="modules" name="footer-4" style="xhtml" headerLevel="3" />
				         </div>
				</footer>
				<?
					}
				?>

			</div><!-- end the footer container's row -->

		</div><!-- end main body container's row -->

	</div><!-- end main body container -->

</body>

</html>
